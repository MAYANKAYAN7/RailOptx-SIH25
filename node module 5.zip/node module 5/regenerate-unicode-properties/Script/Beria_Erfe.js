const set = require('regenerate')();
set.addRange(0x16EA0, 0x16EB8).addRange(0x16EBB, 0x16ED3);
exports.characters = set;
