const set = require('regenerate')();
set.addRange(0x11C70, 0x11C8F).addRange(0x11C92, 0x11CA7).addRange(0x11CA9, 0x11CB6);
exports.characters = set;
