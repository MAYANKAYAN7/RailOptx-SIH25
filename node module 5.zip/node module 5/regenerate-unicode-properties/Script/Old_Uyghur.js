const set = require('regenerate')();
set.addRange(0x10F70, 0x10F89);
exports.characters = set;
