const set = require('regenerate')(0x1091F);
set.addRange(0x10900, 0x1091B);
exports.characters = set;
