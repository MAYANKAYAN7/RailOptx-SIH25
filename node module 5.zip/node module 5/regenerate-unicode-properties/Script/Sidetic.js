const set = require('regenerate')();
set.addRange(0x10940, 0x10959);
exports.characters = set;
