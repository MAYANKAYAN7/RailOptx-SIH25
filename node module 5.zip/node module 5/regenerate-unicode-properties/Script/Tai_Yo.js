const set = require('regenerate')();
set.addRange(0x1E6C0, 0x1E6DE).addRange(0x1E6E0, 0x1E6F5).addRange(0x1E6FE, 0x1E6FF);
exports.characters = set;
