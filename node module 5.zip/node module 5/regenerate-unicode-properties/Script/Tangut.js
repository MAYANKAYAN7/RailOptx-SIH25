const set = require('regenerate')(0x16FE0);
set.addRange(0x17000, 0x18AFF).addRange(0x18D00, 0x18D1E).addRange(0x18D80, 0x18DF2);
exports.characters = set;
