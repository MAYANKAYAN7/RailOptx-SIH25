const set = require('regenerate')();
set.addRange(0x11DB0, 0x11DDB).addRange(0x11DE0, 0x11DE9);
exports.characters = set;
