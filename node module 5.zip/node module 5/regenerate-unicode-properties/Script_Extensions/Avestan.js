const set = require('regenerate')(0xB7);
set.addRange(0x2E30, 0x2E31).addRange(0x10B00, 0x10B35).addRange(0x10B39, 0x10B3F);
exports.characters = set;
