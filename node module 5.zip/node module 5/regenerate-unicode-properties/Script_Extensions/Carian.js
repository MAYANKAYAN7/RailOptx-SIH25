const set = require('regenerate')(0xB7, 0x205A, 0x205D, 0x2E31);
set.addRange(0x102A0, 0x102D0);
exports.characters = set;
