const set = require('regenerate')(0x965);
set.addRange(0x16100, 0x16139);
exports.characters = set;
