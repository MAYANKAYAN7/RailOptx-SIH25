const set = require('regenerate')(0x205D);
set.addRange(0x10980, 0x1099F);
exports.characters = set;
