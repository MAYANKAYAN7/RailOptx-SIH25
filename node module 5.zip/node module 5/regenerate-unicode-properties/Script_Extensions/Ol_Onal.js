const set = require('regenerate')(0x1E5FF);
set.addRange(0x964, 0x965).addRange(0x1E5D0, 0x1E5FA);
exports.characters = set;
