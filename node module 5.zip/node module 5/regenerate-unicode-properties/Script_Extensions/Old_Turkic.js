const set = require('regenerate')(0x205A, 0x2E30);
set.addRange(0x10C00, 0x10C48);
exports.characters = set;
