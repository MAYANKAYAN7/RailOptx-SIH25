const set = require('regenerate')(0xB7);
set.addRange(0x10450, 0x1047F);
exports.characters = set;
