const set = require('regenerate')();
set.addRange(0x964, 0x965).addRange(0x9E6, 0x9EF).addRange(0xA800, 0xA82C);
exports.characters = set;
