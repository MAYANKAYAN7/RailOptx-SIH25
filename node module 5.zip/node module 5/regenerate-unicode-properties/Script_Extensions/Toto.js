const set = require('regenerate')(0x2BC);
set.addRange(0x1E290, 0x1E2AE);
exports.characters = set;
