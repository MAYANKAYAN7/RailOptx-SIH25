'use strict';
const ATRULE = 'atrule';
const DECL = 'decl';
const RULE = 'rule';

module.exports = { ATRULE, DECL, RULE };
