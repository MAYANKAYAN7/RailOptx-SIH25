declare function _exports(node: import('postcss').Rule): boolean;
export = _exports;
