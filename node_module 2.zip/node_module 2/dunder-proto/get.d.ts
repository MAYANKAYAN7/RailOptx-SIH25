declare function getDunderProto(target: {}): object | null;

declare const x: false | typeof getDunderProto;

export = x;