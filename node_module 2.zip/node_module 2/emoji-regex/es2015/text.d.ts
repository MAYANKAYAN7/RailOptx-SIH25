declare module 'emoji-regex/es2015/text' {
  function emojiRegex(): RegExp;

  export = emojiRegex;
}
