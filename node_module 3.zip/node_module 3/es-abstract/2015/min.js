'use strict';

// https://262.ecma-international.org/6.0/#sec-algorithm-conventions

module.exports = require('math-intrinsics/min');
